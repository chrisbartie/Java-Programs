package st10033223_poe;

import java.util.Scanner;

public class ST10033223_POE {

    public static void main(String[] args) {
        
        // Minimum number of letters in the password
        final int MIN = 8;
        // Minimum number of uppercase letters in the password
        final int MIN_Uppercase = 1;
        // Count number of uppercase letters in the password
        int uppercaseCounter = 0;
        // Count digits in the password
        int numberCounter = 0;
        // Count special characters in the password
        int specCharCounter = 0;

        System.out.println("Enter the password");

        Scanner input = new Scanner(System.in);

        String password = input.nextLine();

        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);
            if (Character.isUpperCase(c)) {
                uppercaseCounter++;
            } else if (Character.isDigit(c)) {
                numberCounter++;
            }
            if (c == '$' || c == '#' || c == '?' || c == '!' || c == '_' || c == '=' || c == '%') {
                specCharCounter++;
            }
        }

        if (password.length() >= MIN && uppercaseCounter >= MIN_Uppercase && specCharCounter == 1 && numberCounter == 1) {
            System.out.println("Password successfully captured");
        } else {
            System.out.println("Your password does not contain the following:");

            if (password.length() < MIN) {
                System.out.println("Password should be minimum, 8 characters");
            }
            if (uppercaseCounter != MIN_Uppercase) {
                System.out.println("Password should contain at least 1 uppercase character");
            }
            if (numberCounter != 1) {
                System.out.println("Password should contain a number");
            }
            if (specCharCounter != 1) {
                System.out.println("Password should contain only 1 special characters");
            }//code attribution
            //this method was taken from stack overflow
            //https://stackoverflow.com/questions/71741186/how-can-i-check-for-special-characters-in-password-validation-in-java
            //Kivan Ilangakoon
            //https://stackoverflow.com/users/5254942/kivan-ilangakoon
        }
    }
} //end main

