/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10033223_poe.part3;

import org.junit.Assert;
import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author chris
 */
public class TaskTest {

    @Test
    public void testDeveloperArray() {
        String[] developers = {"Mike Smith", "Edward Harrington", "Samantha Paulson", "Glenda Oberholzer"};

        Assert.assertEquals("Mike Smith", developers[0]);
        Assert.assertEquals("Edward Harrington", developers[1]);
        Assert.assertEquals("Samantha Paulson", developers[2]);
        Assert.assertEquals("Glenda Oberholzer", developers[3]);
    }

    @Test
    public void displayLongest() {
        TaskManager taskManager = new TaskManager();

        // Set up test data
        Task.addTasks("Task 1", "Mike Smith", 8);
        taskManager.addTasks("Task 2", "Edward Harrington", 10);
        taskManager.addTasks("Task 3", "Samantha Paulson", 7);
        taskManager.addTasks("Task 4", "Glenda Oberholzer", 11);

        // Call the method under test
        String result = taskManager.displayLongest();

        // Assert the result
        Assert.assertEquals("Glenda Oberholzer, 11", result);
    }

}
