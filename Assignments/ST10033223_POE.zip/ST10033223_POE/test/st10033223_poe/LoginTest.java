/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10033223_poe;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author chris
 */
public class LoginTest {

    public LoginTest() {
    }

    /**
     * Test of GetcheckUserName method, of class Login.
     */
    @Test
    public void testcheckUserNameValid() {
        String UserName = "Kyl_1";
        boolean result = Login.checkUserName(UserName);
        assertTrue(result);
    }

    @Test
    public void testcheckUserNameInvalid() {
        String UserName = "kyle!!!!!!!";
        boolean result = Login.checkUserName(UserName);
        assertFalse(result);
    }

    /**
     * Test of checkPasswordComplexity method, of class Login.
     */
    @Test
    public void testCheckPasswordComplexityValid() {
        String userPassword = "Ch&&secke99!";
        boolean result = Login.checkPasswordComplexity(userPassword);
        assertTrue(result);
    }

    @Test
    public void testCheckPasswordComplexityInvalid() {
        String userPassword = "password";
        boolean result = Login.checkPasswordComplexity(userPassword);
        assertFalse(result);
    }

    /**
     * Test of registerUser method, of class Login.
     */
    @Test
    public void testRegisterUser() {
        String actual = Login.registerUser("Kyl_1", "Ch&&sec@ke99!");
        String expected = "User successfully registered";
        assertEquals(expected, actual);

        actual = Login.registerUser("Kyl_1", "password");
        expected = "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        assertEquals(expected, actual);

        actual = Login.registerUser("kyle!!!!!!!", "Ch&&sec@ke99!");
        expected = "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length";
        assertEquals(expected, actual);

    }
    

    /**
     * Test of loginUser method, of class Login.
     */
    @Test
    public void testLoginUser() {
        Login.setUserName("Kyl_1");
        Login.setPassword("Ch&&sec@ke99!");
        assertTrue(Login.loginUser("Kyl_1", "Ch&&sec@ke99!"));
        assertFalse(Login.loginUser("kyle!!!!!!!", "password"));

    }

}
