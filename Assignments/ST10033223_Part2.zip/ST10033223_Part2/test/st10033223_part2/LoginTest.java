/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10033223_part2;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author chris
 */
public class LoginTest {
    
    public LoginTest() {
    }

    @Test
    public void testGetUserName() {
    }

    @Test
    public void testSetUserName() {
    }

    @Test
    public void testGetPassword() {
    }

    @Test
    public void testSetPassword() {
    }

    @Test
    public void testGetFirstName() {
    }

    @Test
    public void testSetFirstName() {
    }

    @Test
    public void testGetLastName() {
    }

    @Test
    public void testSetLastName() {
    }

    @Test
    public void testCheckUserName() {
    }

    @Test
    public void testCheckPasswordComplexity() {
    }

    @Test
    public void testRegisterUser() {
    }

    @Test
    public void testLoginUser() {
    }

    @Test
    public void testReturnLoginStatus() {
    }
    
}
