/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10033223_part2;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 *
 * @author chris
 */
public class TaskTest {

    public TaskTest() {
    }

    @Test
    public void testGetTaskDescriptionValid() {
        Task task = new Task();
        task.setTaskDescription("Valid task description");

        boolean result = task.checkTaskDescription();

        assertTrue(result);

    }

    @Test
    public void testSetTaskDescriptionFalse() {
        Task task = new Task();

        task.setTaskDescription("This is a very long description that exceeds the maximum allowed characters");

        assertFalse(task.checkTaskDescription());

    }

    @Test
    public void testReturnTotalHours() {
        
        //code attribution 
        //this code was taken from w3schools
        //https://www.w3schools.com/java/java_howto_sum_of_array_elements.asp 
        //2023

        int[] hoursFirstTest = {10, 8};
        int[] hoursSecondTest = {10, 12, 55, 11, 1};
        Task task = new Task();
        task.initArray(50);
        for (int i = 0; i < 5; i++) {
            task.setTaskDuration(hoursSecondTest[i]);
            task.getDuration(hoursSecondTest[i]);
        }
        assertEquals(task.returnTotalHours(), 89);
        task.setTotalTaskDuration(0);
        for (int i = 0; i < 2; i++) {
            task.setTaskDuration(hoursFirstTest[i]);
            task.getDuration(hoursFirstTest[i]);
        }
        assertEquals(task.returnTotalHours(), 18);
    }

//    @Test
//    public void testCreateTaskID() {
//        Task task = new Task();
//        task.initArray();
//        String[] expectedOutcome = {"CR:0:IKE", "CR:1:ARD", "CR:2:THA", "AD:3:NDA"};
//        String[] developerNames = {"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
//        String[] taskName = {"Create Login", "Create Add Features", "Create Reports", "Add Arrays"};
//
//        
//        for (int i = 1; i <= 4; i++) { 
//            task.setTaskDeveloperDetails(developerNames[i - 1]); 
//            task.setTaskName(taskName[i - 1]); 
//            task.setTaskNumber(i - 1); 
//            String actualOutcome = task.createTaskID();
//            assertEquals(expectedOutcome[i - 1], actualOutcome); 
//        }
//
//    }
    //couldn't manage to get this test to work
}
//Reference List
//w3schools. 2023. Java How to Calculate the Sum of Elements, [n.d]. [Online]. Availible at: https://www.w3schools.com/java/java_howto_sum_of_array_elements.asp [Accessed 6 June 2023].

